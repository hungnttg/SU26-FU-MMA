const express = require('express');
const User = require('../model/User');
const router = express.Router();
//lay tat ca cac user
router.get('/',async (req,res)=>{
    try {
        res.json(await User.find());//lay ve tat ca user
    } catch (error) {
        res.status(500).json({message:error.message});
    }
});
//login
router.post('/login',async (req,res)=>{
    try {
        const user = await User.findOne({username: req.body.username});
        if(!user || user.password !== req.body.password){
            return res.status(401).json({message:'Invalid username or pass'});
        }
        res.json({token:user.username,role: user.role});//tra ve token
    } catch (error) {
        res.status(500).json({message:'Server error'});
    }
});
module.exports=router;