//npm i express mongoose
//npm i cors
//npm i body-parser
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const useRoutes = require('./routes/users');
//
const app = express();
//ket noi den mongodb
mongoose.connect('mongodb://localhost:27017/a2',{})
.then(()=>console.log('Connected'))
.catch(err => console.log(err));
//middleware
app.use(cors());
app.use(bodyParser.json());
//cac route
app.use('/api/users',useRoutes);
//lang nghe
app.listen(3001,()=>{
    console.log('server dang chay o cong 3001');
});