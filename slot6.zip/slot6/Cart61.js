import React,{useState} from "react";
import { View,ScrollView,Button,FlatList,Text } from "react-native";
import ProductFn from "./Product61";
global.mycart=[];//bien toan cuc
const CartFn = ({route}) =>{
    //code-------------------------------
    const [count,setCount]=useState(1);//dem san pham
    const [list,setList]=useState(global.mycart);//lay du lieu tu bien toan cuc
    const data = route.params?.data || "";//lay data tu Detail
    //lay toan bo san pham trong gio hang
    const allProductInCart = () =>{
        const newList = [{data},...global.mycart];//them san pham vao gio hang
        global.mycart = newList;//cap nhat laij bien toan cuc
        setList([...newList]);//cap nhat state de render
    };
    //ket xuat du lieu tronhg gio hang
    const renderItemCart = ({index,item}) =>{
        return(
            <ProductFn dataProd={global.mycart[index].data}/>
        );
    }
   //layout-------------------------------
   return(
    <View>
        <ScrollView>
            <ProductFn dataProd={data}/>
            <Button title="+" onPress={()=>setCount(count+1)}/>
            <Text>So luong san pham: {count}</Text>
            <Button title="-" onPress={()=>setCount(count-1)}/>
            <Button title="All Product In Cart" onPress={allProductInCart}/>
            <FlatList
                data={list}
                renderItem={({index,item})=>renderItemCart({index,item})}
                numColumns={2}
                removeClippedSubviews
            />
        </ScrollView>
    </View>
   );
}
export default CartFn;