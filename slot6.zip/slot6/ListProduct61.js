//npm i @react-navigation/stack
//npm i @react-navigation/native
import React,{useState,useEffect} from "react";
import { FlatList } from "react-native";
import { useNavigation, useRoute } from '@react-navigation/native';
import {} from '@react-navigation/stack';
import ProductFn from "./Product61";
const ListProductFn = () =>{
    //code--------------------------------
    const navigation = useNavigation();//su dung navigation
    const route = useRoute();//dinh huong vi tri dieu huong den
    const [prd, setPrd]=useState(null);//bien quan ly product
    //ham ket xuat du lieu
    const renderItemFlatlist = ({item}) =>{
        return(
        <ProductFn dataProd={item} handlePress={()=>viewDetail({p: item})} />
        );
    };
    //dinh nghia viewDetail
    const viewDetail = ({p}) =>{
        navigation.navigate('DetailFn',{data:p});
    };
    //ham doc du lieu tu API
    const getProducts = async () =>{
        const url = 'https://hungnttg.github.io/shopgiay.json';//duong dan
        const res = await fetch(url,{method:'GET'});//doc du lieu
        const resJSON = await res.json();//chuyen sang json
        //cap nhat vao bien prd
        setPrd(resJSON.products);
    };
    //goi ham doc du lieu tu API
    useEffect(()=>{
        getProducts();
    },[]);
    //layout---------------------------------
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatlist}
            numColumns={3}
            removeClippedSubviews
        />
    );
}
export default ListProductFn;