import React from "react";
import { ScrollView,Button } from "react-native";
import ProductFn from "./Product61";
const DetailFn = ({navigation,route}) =>{
    //code--------------------------
    const data1 = route.params?.data || ""; //nhan du lieu tu List chuyen sang
    //ham them san pham vao gio hang
    const addToCart = ({d}) =>{
        navigation.navigate('CartFn',{data: d});
    };
    //layout--------------------------
    return(
        <ScrollView>
            <ProductFn dataProd={data1}/>
            <Button title="Add to Cart" onPress={()=>addToCart({d:data1})}/>
        </ScrollView>
    );
}
export default DetailFn;