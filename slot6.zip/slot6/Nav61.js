import { createStackNavigator } from "@react-navigation/stack";
import DetailFn from "./Detail61";
import ListProductFn from "./ListProduct61";
import CartFn from "./Cart61";
const Stack = createStackNavigator();
const NavFn = () =>{
    return(
        <Stack.Navigator initialRouteName="ListProductFn">
            <Stack.Screen name="ListProductFn" component={ListProductFn}/>
            <Stack.Screen name="DetailFn" component={DetailFn}/>
            <Stack.Screen name="CartFn" component={CartFn}/>
        </Stack.Navigator>
    );
}
export default NavFn;