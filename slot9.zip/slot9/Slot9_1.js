import React from "react";
import { View,Text,StyleSheet } from "react-native";
// dinh nghia view
const SectionView = ({title,children,backgroundColor}) =>{
    return(
        <View style = {[styles.container,{backgroundColor}]}>
            <Text style={styles.title}>{title}</Text>
        </View>
    );
};
//app dung
const Slot9_1 = () =>{
    return(
        <View style={styles.container}>
            <SectionView title="Header" backgroundColor="#ffcccc">
                <Text>Header content goes here</Text>
            </SectionView>
            <SectionView title="Content" backgroundColor="#ccffcc">
                <Text>Content goes here</Text>
            </SectionView>
            <SectionView title="Footer" backgroundColor="#ccccff">
                <Text>Footer content goes here</Text>
            </SectionView>
        </View>
    );
}
export default Slot9_1;

const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    title:{
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 10,
    }
});