import React, {useState} from "react";
import { Text,StyleSheet,View,TextInput,Button } from "react-native";
const Slot9_3 = () =>{
    //code
    const [inputValue,setInputValue]=useState('');
    const [isInputValid, setIsInputValid]=useState(true);
    //ham
    const handleBlur = () =>{
        setIsInputValid(inputValue.trim() !== '');
    };
    const handleSubmit = () =>{
        setIsInputValid(inputValue.trim() !== '');
    };
    //layout
    return(
        <View style={styles.container}>
            <TextInput
                style={[styles.input, !isInputValid && styles.invalid]}
                placeholder="Nhap ten ..."
                onChangeText={text => {
                    setInputValue(text);
                    setIsInputValid(true);
                }}
                onBlur={handleBlur}
            />
            {!isInputValid && <Text style={styles.errorText}>
                Vui long khong de trong    
            </Text>}
            <Button title="Submit" onPress={handleSubmit} />
        </View>
    );
}
export default Slot9_3;
const styles = StyleSheet.create({
    container: {
        flex:1,
        justifyContent:'center',
        alignItems:'center',
    },
    input:{
        borderWidth:1,
        borderColor: '#ccc',
        padding:10,
        marginBottom:10,
        width:'80%'
    },
    invalid: {
        borderColor:'red',
    },
    errorText: {
        color:'red',
        marginBottom:10,
    },
});