//npm i body-parser
const express = require('express');
const mongoose =require('mongoose');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/products');
//tao doi tuong app
const app = express();
//cau hinh view engine la ejs
app.set('view engine','ejs');
//middleware
app.use(bodyParser.urlencoded({extended:true}));
//ket noi mongo
mongoose.connect('mongodb://localhost:27017/a1',{

}).then(()=>{
    console.log('Ket noi DB thanh cong');
}).catch(err=>{
    console.log('Co loi ket noi db: ',err.message);
});
//su dung route quan tri san pham
app.use('/',productRoutes);
//lang nghe ket noi
app.listen(3000,()=>{
    console.log('Server dang chay o cong 3000');
});