//npm i express
const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
//hien thi danh sach san pham
router.get('/admin',async (req,res)=>{
    try {
        const products = await Product.find();
        res.render('admin',{products,product:null});
    } catch (error) {
       res.status(500).send(error.message); 
    }
});
//them san pham
router.post('/add-product',async (req,res)=>{
    const {id,name,price,description}=req.body;//lay gia tri tu form nhap
    const newProduct = new Product({id,name,price,description});
    try {
        await newProduct.save();
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//lay thong tin de edit san pham
router.get('/edit-product/:id',async (req,res)=>{
    try {
        //lay san pham can edit
        const product = await Product.findById(req.params.id);
        const products = await Product.find();//lay toan bo danh sach
        res.render('admin',{product,products});//hien thi toan bo san pham len admin
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//sua san pham
router.post('/edit-product/:id',async (req,res)=>{
    const {name,price,description}=req.body;//lay thong tin can sua
    try {
        //thuc hien update
        await Product.findByIdAndUpdate(req.params.id,{name,price,description});
        res.redirect('/admin');//dieu huong ve trang admin
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//xoa san pham
router.post('/delete-product/:id',async (req,res)=>{
    try {
        await Product.findByIdAndDelete(req.params.id);//thuc hien xoa
        res.redirect('/admin');//chuyen huong ve admin
    } catch (error) {
        res.status(500).send(error.message);
    }
});
module.exports=router;