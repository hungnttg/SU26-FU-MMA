//npm i mongoose
const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    id: {type: String, require: true, unique: true},
    name: {type: String, require: true},
    price: {type: String, require: true},
    description: {type: String, require: true},
});
const Product = mongoose.model('Product',productSchema);
module.exports = Product;