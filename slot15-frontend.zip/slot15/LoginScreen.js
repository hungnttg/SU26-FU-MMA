import React,{useState} from "react";
import { View,Text,TextInput,Button,StyleSheet } from "react-native";
import { loginUser } from "./api";//nhap ham login
const LoginScreen = () =>{
    const [username,setUsername]=useState('');
    const [password,setPassword]=useState('');
    const [message,setMessage]=useState('');
    const [error,setError]=useState('');
    const handleLogin = async () =>{
        try {
            const response = await loginUser(username,password);
            if(response.role){//kiem tra role de quyet dinh dieu huong
                //navigation.navigate('Home',{role:resonse.role});
                setMessage("Login successful");
                console.log(response);
            }
        } catch (error) {
            setError(error.message);
            console.error('Login failed: ',error);
        }
    }
    //giao dien
    return(
        <View style={{flex:1}}>
            <Text style={{fontSize:30}}>Username:</Text>
            <TextInput
                style={{borderWidth:1}}
                value={username}
                onChangeText={setUsername}
                placeholder="Enter username"
            />
            <Text style={{fontSize:30}}>Password:</Text>
            <TextInput
                style={{borderWidth:1}}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter password"
                secureTextEntry
            />
            {error ? <Text style={{color:'red'}}>{error}</Text>
            : <Text>{message}</Text>}
            <Button title="Login" onPress={handleLogin}/>
            
        </View>
    );
}
export default LoginScreen;