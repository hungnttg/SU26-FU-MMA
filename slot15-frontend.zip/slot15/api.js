import axios from "axios";
const API_BASE_URL = 'http://localhost:3001/api';
//ham login
export const loginUser = async (username,password)=>{
    try {
        const API_URL=`${API_BASE_URL}/users/login`;
        const response = await axios.post(API_URL,{username,password});
        console.log("Result: "+response.data);
        //neu danh nhap thanh cong, tra ve token va role
        return response.data;
    } catch (error) {
        throw new Error(error);
    }
};