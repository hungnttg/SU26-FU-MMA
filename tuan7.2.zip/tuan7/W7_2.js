//left menu
//npm i @react-navigation/native
//npm i @react-navigation/drawer
//npm i react-native-gesture-handler
//npm i react-native-reanimated
//npm i react-native-screens
//npm i react-native-vector-icons
import React from "react";
import { Text,View,Button,TouchableOpacity } from "react-native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { NavigationContainer } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { createStackNavigator } from "@react-navigation/stack";
const Drawer = createDrawerNavigator(); //tao left menu
const Stack = createStackNavigator();
//man hinh home
const HomeScreen = ({navigation}) => (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
        <TouchableOpacity onPress={()=>navigation.openDrawer()}
        style={{position:'absolute',left:20,top:50}}>
            <Ionicons name="menu" size={32} color="black"/>
        </TouchableOpacity>
        <Text>Home Screen</Text>
    </View>
);
//man hinh setting
const SettingsScreen = () =>(
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
        <Text>Settings Screen</Text>
    </View>
);
export default function Left(){
    return(
        <Drawer.Navigator initialRouteName="Home">
            <Drawer.Screen name="Home" component={HomeScreen}/>
            <Drawer.Screen name="Settings" component={SettingsScreen}/>
        </Drawer.Navigator>
    );
}
