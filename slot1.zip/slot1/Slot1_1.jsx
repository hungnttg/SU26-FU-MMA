//1. Import thu vien
import React from "react";
import { Text, View } from "react-native";
// 2.DInh nghia class
export default class Slot1_1 extends React.Component{
    //Code
    //Layout
    render(){
        return(
            <View>
                <Text>Day la ung dung Class</Text>
            </View>
        );
    }
}