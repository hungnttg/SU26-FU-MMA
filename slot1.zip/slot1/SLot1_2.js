//1. Import thu vien
import { Text, View } from "react-native";
// 2. DInh nghia ham
const Slot1_2 = () => {
    //code
    //layout
    return(
        <View>
            <Text>Day la phien ban Function</Text>
        </View>
    );
}
export default Slot1_2;