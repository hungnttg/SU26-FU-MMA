import React from "react";
import { Text,View } from "react-native";
export default class SLot2_1 extends React.Component {
    //code
    //layout
    render(){
        return(
            <View>
                <Text>Xin chao react native</Text>
            </View>
        );
    }
}