import React,{useState} from "react";
import { Text,View,Button } from "react-native";
export default function SLot2_4(){
    //------------------code---------------
    const [count, setCount]=useState(0);
    //count: bien; setCount: phuong thuc cap nhat; 0: gia tri khoi tao
    //------------------layout-------------
    return(
        <View>
            <Text>Ban vua lick lan thu {count}</Text>
            <Button onPress={()=>setCount(count+1)} title="CLick me"/>
        </View>
    );
}