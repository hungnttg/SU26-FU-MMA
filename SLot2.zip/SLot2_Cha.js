import React from "react";
import { Text,View } from "react-native";
import Slot2_Con from "./Slot2_Con";
export default function Slot2_Cha(){
    const userName = 'An'
    return(
        <View>
            {/* trong component cha, goi component con va truyen props */}
            <Slot2_Con name={userName}/>
        </View>
    );
}