import React from "react";
import { Text,View } from "react-native";
export default function Slot2_Con({name}){
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}