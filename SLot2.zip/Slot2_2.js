import React from "react";
import { Text,View } from "react-native";
export default function Slot2_2(){
    //code
    //layout
    return(
        <View>
            <Text>Day la React Native, phien ban function</Text>
        </View>
    );
}