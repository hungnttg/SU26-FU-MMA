//dem
import React from "react";
import { Text,View } from "react-native";
export default class Slot2_3 extends React.Component{
    //-------------------------code----------------
    //ham khoi tao
    constructor(props){
        super(props);
        this.state={
            text: "Click me",
            dem: 0,
        };
    }
    //ham update text
    updateText(){
        this.setState((preState)=>{
            return {
                dem: preState.dem +1,
                text: 'ban vua click lan ',
            }
        });
    }
    //-------------------------layout---------------
    render(){
        return(
            <View>
                <Text onPress={()=>this.updateText()}>
                    {this.state.text} : {this.state.dem}
                </Text>
            </View>
        );
    }
}