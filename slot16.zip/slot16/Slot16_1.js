import React,{useState,useEffect} from "react";
import { View,TextInput,Button,FlatList,StyleSheet } from "react-native";
import { addDoc, collection, doc, onSnapshot, updateDoc } from 'firebase/firestore';
import {FIRESTORE_DB} from '../../../firebaseConfig';
const ITEMS_COLLECTION = collection(FIRESTORE_DB,'items');//bang du lieu
const Slot16_1 = () =>{
    const [text,setText]=useState();
    const [items,setItems]=useState([]);
    useEffect(()=>{
        const unsub = onSnapshot(ITEMS_COLLECTION,(snapshot)=>{
            const updatedItems = [];
            snapshot.forEach((doc)=>{
                updatedItems.push({id:doc.id,...doc.data()});
            });
            setItems(updatedItems);
        });
        return ()=>unsub();
    },[]);
    //ham them du lieu vao firebase
    const handleAddData = async () =>{
        try {
            await addDoc(ITEMS_COLLECTION,{
                text:text
            });
            setText('');
        } catch (error) {
            console.error('Error adding document: ',error);
        }
    };
    //ham cap nhat du lieu vao firebase
    const handleUpdateData = async (itemId,newText) =>{
        try {
            const itemDoc = doc(FIRESTORE_DB,'items',itemId);
            await updateDoc(itemDoc,{text:newText});
        } catch (error) {
            console.error('Error updateing document: ',error);
        }
    };
    //ham xoa du lieu tu firebase
    const handleDeleteData = async (itemId) =>{

    };
    //ham render du lieu
    const renderItem = ({item}) =>(
        <View style={{flexDirection:'row',justifyContent:'space-between',
            alignItems:'center',marginBottom:10 }}>
            <TextInput
                style={{flex:1,marginRight:10}}
                value={item.text}
                onChangeText={(newText)=>handleUpdateData(item.id,newText)}
            />
            <Button title="Delete" onPress={()=>handleDeleteData(item.id)}/>
        </View>
    );
    return(
        <View style={{flex:1,padding:20}}>
            <TextInput
                placeholder="Enter Text"
                value={text}
                onChangeText={setText}
                style={{marginBottom:10}}
            />
            <Button
                title="Add Data"
                onPress={handleAddData}
                style={{marginBottom:20}}
            />
            <FlatList
                data={items}
                renderItem={renderItem}
                keyExtractor={(item)=>item.id}
            />
        </View>
    );
}
export default Slot16_1;