import React,{useState} from "react";
import { View,TextInput,Button } from "react-native";
import { addDoc, collection } from 'firebase/firestore';
import {FIRESTORE_DB} from '../../../firebaseConfig';

const Slot16 = () =>{
    const [text,setText]=useState('');
    const handleAddData = async () =>{
        try {
            //them du lieu vao firebase
            const docRef = await addDoc(collection(FIRESTORE_DB,'items'),{
                text: text
            });
            console.log('Document written with ID: ',docRef.id);
            setText('');//reset
        } catch (error) {
            console.error('Error adding document: ',error);
        }
    };
    //layout
    return(
        <View>
            <TextInput
                placeholder="Enter Text"
                style={{borderWidth:1}}
                value={text}
                onChangeText={setText}
            />
            <Button
                title="Add Data"
                onPress={handleAddData}
            />
        </View>
    );
}
export default Slot16;