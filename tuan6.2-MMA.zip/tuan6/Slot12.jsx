//npm i @reduxjs/toolkit
//npm i react-redux
import React from "react";
import { View } from "react-native";
import { Provider } from "react-redux";
import store from "./store";
import ProductList from "./ProductList";
import Cart from "./Cart";
//khai bao mang
const products = [
    {id:1,name:'Product 1'},
    {id:2,name:'Product 2'},
    {id:3,name:'Product 3'},
    {id:4,name:'Product 4'}
];
const Slot12 = () =>{
    return(
        <Provider store={store}>
            <View>
                <ProductList products={products}/>
                <Cart/>
            </View>
        </Provider>
    );
};
export default Slot12;