//hệ thống quản lý thửa đất
//luu tru o SyncStorage
//co 3 man hinh: Home, Detail, Edit
//npm i @react-native-async-storage/async-storage
import React,{useState,useEffect,useCallback} from "react";
import { useFocusEffect } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Text,View,TextInput,Button,FlatList,TouchableOpacity } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';

//dinh nghia 3 man hinh
const HomeScreen = ({navigation}) =>{
    //code
    const [lands,setLands]=useState([]);
    const [search,setSearch]=useState('');
    //load du lieu tu SyncStorage
    useFocusEffect(
        useCallback(()=>{
            (async () => {
                //doc du lieu tu local storage
                const data = await AsyncStorage.getItem('lands');
                //cap nhat vao state
                setLands(data ? JSON.parse(data):[]);
            })();
        },[])
    );
    //layout//list san pham
    return(
        <View style={{flex:1, padding:10}}>
            <TextInput placeholder="Tim kiem..." onChangeText={setSearch}/>
            <FlatList
                data={lands.filter(l=>l.name.includes(search)||
                l.location.includes(search))}
                keyExtractor={item => item.id}
                renderItem={({item})=>(
                    <TouchableOpacity onPress={()=>navigation.navigate('Detail',{land:item})}>
                        <Text>{item.name} - {item.location}</Text>
                    </TouchableOpacity>
                )}
            />
            <Button title="Them"onPress={()=>navigation.navigate('Edit')} />
        </View>
    );
};
//man hinh them
const  LandScreen =  ({navigation,route}) =>{
    //nhan du lieu tu home chuyen sang
    const [land,setLand]=useState(route.params?.land || 
        {id:Date.now().toString,name:'',location:'',price:''});
        //luu du lieu vao localStorage
        const saveLand = async () =>{
            //doc du lieu tu local storage
            const storedLands = 
            JSON.parse(await AsyncStorage.getItem('land'))||[];
            //them du lieu vao local storage
            await AsyncStorage.setItem('lands',
                JSON.stringify(route.params?.land ?
                    storedLands.map(l=>l.id === land.id ?
                        land: l
                    ): [...storedLands,land]
                )
            );
            navigation.goBack();
        };
        //giao dien
        return(
            <View style={{flex:1,padding:10}}>
                <TextInput placeholder="Ten" value={land.name}
                onChangeText={v=>setLand({...land,name:v})}/>
                <TextInput placeholder="Vi tri" value={land.location}
                onChangeText={v=>setLand({...land,location:v})}/>
                <TextInput placeholder="Gia" value={land.price}
                onChangeText={v=>setLand({...land,price:v})} keyboardType="numeric"/>
                <Button title="Save" onPress={saveLand}/>
            </View>
        );
};
const DetailScreen = ({route, navigation}) =>{
    const {land} = route.params;
    //viet ham xoa du lieu
    const deletedLand = async () => {
        //doc du lieu tu localstorage
        const storedLands = 
        JSON.parse(await AsyncStorage.getItem('lands'))||[];
        //xoa du lieu
        await AsyncStorage.setItem('lands',
            JSON.stringify(storedLands.filter(l=>l.id !== land.id))
        );
        navigation.goBack();
    };
    //giao dien
    return(
        <View style={{flex:1,padding:10}}>
            <Text>{land.name}</Text>
            <Text>{land.location}</Text>
            <Text>{land.price}</Text>
            <Button title="Xoa" onPress={deletedLand}/>
            <Button title="Sua" onPress={()=>navigation.navigate('Edit',{land})} />
        </View>
    );
};
const Stack = createStackNavigator();
export default function Slot11(){
    return(
        <Stack.Navigator initialRouteName="Home">
            <Stack.Screen name="Home" component={HomeScreen}/>
            <Stack.Screen name = "Edit" component={LandScreen} />
            <Stack.Screen name="Detail" component={DetailScreen} />
        </Stack.Navigator>
    );
}