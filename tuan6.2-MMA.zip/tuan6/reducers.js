import { createReducer } from "@reduxjs/toolkit";
import { addItem,removeItem } from "./actions";
const initialState = {items: []};
const cartReducer = createReducer(initialState,builder =>{
    builder
    .addCase(addItem,(state,action)=>{
        //kiem tra xem id san pham co ton tai khong
        const existingItemIndex = state.items.findIndex(
            item=>item.id === action.payload.id
        );
        //neu ton tai
        if(existingItemIndex !== -1){
            //so luong cong them 1
            state.items[existingItemIndex].quantity++;
        }
        else {//neu khong ton tai ID
            //them moi san pham vao gio hang
            state.items.push({...action.payload,quantity:1});
        }
    })
    .addCase(removeItem,(state,action)=>{
        //lay ve id
        const existingItemIndex = state.items.findIndex(
            item => item.id === action.payload.id
        );
        //neu ton tai ID, khi xoa ta giam so luong di 1
        if(existingItemIndex !== -1){
            state.items[existingItemIndex].quantity--;
            //neu so luong = 0, thi xoa item
            if(state.items[existingItemIndex].quantity === 0){
                state.items.splice(existingItemIndex,1);
            }
        }
    });
});
export default cartReducer;