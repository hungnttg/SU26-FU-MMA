import React from "react";
import { Text,View,Image,TouchableWithoutFeedback,StyleSheet } from "react-native";
//dinh nghia model
const Product = (props) => {
    //code
    const {
        dataProd={},
    } = props;
    //layout
    return(
        <View style={styles.container}>
            <TouchableWithoutFeedback>
                <View>
                    <Image source={{uri:dataProd.search_image}} style={styles.image}/>
                    <Text>{dataProd.styleid}</Text>
                    <Text>{dataProd.brands_filter_facet}</Text>
                    <Text>{dataProd.price}</Text>
                </View>
            </TouchableWithoutFeedback>
        </View>
    );
}
export default Product;
const styles = StyleSheet.create({
    container:{
        flex:1,
    },
    image:{
        width:200,height:200,borderWidth:1,
    }
});