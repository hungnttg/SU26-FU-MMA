import React from "react";
import { FlatList } from "react-native";
import Product from "./Slot5_1_Model";
export default class ListProduct extends React.Component{
    //-------------------code
    constructor(props){
        super(props);
        this.state={
            products:null,
        };
        //khai bao cac ham
        this.getProducts = this.getProducts.bind(this);//lay san pham
        this.renderItem=this.renderItem.bind(this);//hien thi
    }
    //goi ham load du lieu
    componentDidMount(){
        this.getProducts(); //goi ham load du lieu
    }
    //dinh nghia ham getProducts
    async getProducts(){
        const url ='https://hungnttg.github.io/shopgiay.json';//link
        let response = await fetch(url,{method:'GET'});//phuong thuc doc du lieu
        let responseJSON = await response.json();//chuyen sang json
        //cap nhat vao state
        this.setState({
            products: responseJSON.products,
        });
    }
    //dinh nghia ham hien thi du lieu
    renderItem({item}){
        return(
            <Product dataProd={item}/>
        );
    }
    //-------------------layout
    render(){
        return(
            <FlatList
                data={this.state.products} //nguon du lieu
                renderItem={this.renderItem} //cach hien thi
                numColumns={3} //
                removeClippedSubviews
            />
        );
    }
}